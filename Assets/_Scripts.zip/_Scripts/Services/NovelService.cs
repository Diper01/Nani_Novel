using Cysharp.Threading.Tasks;
using UnityEngine;
using Naninovel;


public class NovelService : MonoBehaviour
{
  // public UniTask InitializeServiceAsync () => UniTask.CompletedTask;
  // public void OverrideConfiguration (NovelServiceConfiguration configuration) { }
  //
  // public async UniTask PlayMiniGameAsync ()
  // {
  //   await SceneLoader.LoadSceneAsync("CardMatchMinigame");
  //   await GameEvents.OnMiniGameComplete;
  //   await SceneLoader.LoadSceneAsync("NovelCore");
  // }
  // public class NovelServiceConfiguration : EngineConfiguration
  //  {
  //    // you can leave this empty, or add config fields for your service
  //  }

} 